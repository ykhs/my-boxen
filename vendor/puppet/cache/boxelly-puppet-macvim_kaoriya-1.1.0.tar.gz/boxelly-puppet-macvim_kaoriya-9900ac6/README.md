# MacVIM Kaoriya Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxelly/puppet-macvim_kaoriya.png?branch=master)](https://travis-ci.org/boxelly/puppet-macvim_kaoriya)

## Usage

```puppet
include macvim_kaoriya
```

## Required Puppet Modules

* `boxen`
* `stdlib`
