require 'spec_helper'

describe 'macvim_kaoriya' do
  it do
    should contain_package('MacVim').with({
      :provider => 'appdmg',
      :source   => 'https://macvim-kaoriya.googlecode.com/files/macvim-kaoriya-20131126.dmg',
    })
  end
end
